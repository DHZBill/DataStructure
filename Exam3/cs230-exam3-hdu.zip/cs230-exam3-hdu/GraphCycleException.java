/**
 * DO NOT CHANGE THIS FILE.
 * 
 * An exception to throw when encountering an unexpected cycle.
 */
@SuppressWarnings("serial")
public class GraphCycleException extends Exception {

}
